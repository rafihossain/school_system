@extends('backend.layouts.app')
@section('title', 'Homework Create')
@section('content')

<h4 class="m-0 header-title text-end float-end">
    <a class="btn btn-primary" href="{{route('backend.homework.create')}}">+ Create</a>
</h4>

@if(Session::has('success'))
<div class="alert alert-success" style="text-align: center;">
    {{ Session::get('success') }}
</div>
@endif
<div class="alert alert-success d-none success_msg_show" style="text-align: center;">

</div>

<div class="alert alert-danger danger_msg_show text-center" style="display: none;">

</div>

<div class="col-md-9 m-auto mb-3">
    <div class="row justify-content-center">
       
        <div class="col-md-3 show_section" style="display: none;">

            <button type="button" class="btn btn-primary get_exam_schedule">Get Exam</button>

        </div>

    </div>
</div>

<div class="show_class_examSchedule">

</div>
<script>
    $(document).ready(function() {
        $("#getExam").on('change', function(e) {
            $(".show_section").css('display', 'block');
        });

        $('.get_exam_schedule').click(function(e) {
            var exam_id = $("#getExam").val();
            $.ajax({
                url: "{{route('backend.get_exam')}}",
                type: 'GET',
                data: {
                    'exam_id': exam_id
                },
                success: function(data) {
                    $(".show_class_examSchedule").html(data);
                    // $("#subject_id").html(data['subjects']);

                }
            })
        });
    });
</script>
@endsection